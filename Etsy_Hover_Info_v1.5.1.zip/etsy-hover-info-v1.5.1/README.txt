Etsy Listing Info - Hover v1.5.1

Install:
1. Extract this ZIP.
2. Open chrome://extensions/
3. Enable Developer mode.
4. Remove/disable the older Etsy Hover Info extension.
5. Click Load unpacked and select the etsy-hover-info-v1.5.1 folder.
6. Refresh Etsy search/listing pages.

Hover an Etsy product card to see:
- Store Age
- Total Sales
- Rating + Review count (example: ★ 4.8 (6.7k))
- Shipping From / Ships From

v1.5.1 fix: Store Age was not resolving on many shops because the
creation date is served as a bare Unix timestamp field (e.g.
creation_tsz) rather than a quoted date string. Age detection now
also reads that field, JSON-LD foundingDate, <time> elements, and
the shop's About page as extra fallbacks.

The extension uses Etsy page/embedded data and shop/listing fallbacks. It does not invent missing values; if Etsy does not expose a value, it shows Not found.
